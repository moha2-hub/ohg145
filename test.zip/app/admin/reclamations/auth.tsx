"use server"

// Re-export getCurrentUser from the main auth file
export { getCurrentUser } from "@/app/actions/auth"
