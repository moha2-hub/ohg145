import { getCurrentUser } from "@/app/actions/auth"
import { query } from "@/lib/db"
import { Buffer } from "buffer" // For converting receipt to base64

// 🟢 1. Customer submits a top-up request
export async function requestTopUp(formData: FormData) {
  const user = await getCurrentUser()
  if (!user || user.role !== "customer") {
    return { success: false, message: "Only customers can request top-ups" }
  }

  const amountRaw = formData.get("amount")
  const paymentMethod = formData.get("paymentMethod") as string | null
  const notes = (formData.get("notes") as string) || ""
  const receipt = formData.get("receipt") as File | null

  // Validate amount
  const amount = typeof amountRaw === "string" ? Number.parseInt(amountRaw) : NaN
  if (isNaN(amount) || amount <= 0) {
    return { success: false, message: "Invalid amount" }
  }

  if (!paymentMethod) {
    return { success: false, message: "Payment method is required" }
  }

  if (!receipt) {
    return { success: false, message: "Receipt file is required" }
  }

  try {
    // Convert receipt to base64
    const arrayBuffer = await receipt.arrayBuffer()
    const base64String = `data:${receipt.type};base64,${Buffer.from(arrayBuffer).toString("base64")}`

    // Insert transaction
    const result = await query(
      `INSERT INTO transactions (user_id, type, amount, status, payment_method, receipt_data, notes)
       VALUES ($1, 'top_up', $2, 'pending', $3, $4, $5) RETURNING id`,
      [user.id, amount, paymentMethod, base64String, notes],
    )

    const transactionId = result[0].id

    // Notify all admins
    await query(
      `INSERT INTO notifications (user_id, title, message, type, reference_id)
       SELECT id, 'New Top-up Request', 'A new point top-up request needs verification', 'payment', $1
       FROM users WHERE role = 'admin'`,
      [transactionId],
    )

    return { success: true, transactionId }
  } catch (error) {
    console.error("Request top-up error:", error)
    return { success: false, message: "Failed to submit top-up request" }
  }
}

// 🟢 2. Admin verifies a top-up request
export async function verifyTopUp(transactionId: number, adminId: number) {
  try {
    // Update transaction status
    await query(
      `UPDATE transactions SET status = 'verified' WHERE id = $1 AND status = 'pending'`,
      [transactionId],
    )

    // Get customer ID
    const result = await query(
      `SELECT user_id FROM transactions WHERE id = $1`,
      [transactionId],
    )

    if (result.length > 0) {
      const customerId = result[0].user_id

      // Notify the customer
      await query(
        `INSERT INTO notifications (user_id, title, message, type, reference_id)
         VALUES ($1, 'Top-up Verified', 'Your top-up has been verified by admin', 'payment', $2)`,
        [customerId, transactionId],
      )
    }

    return { success: true }
  } catch (error) {
    console.error("Error verifying top-up:", error)
    return { success: false }
  }
}

// 🟢 3. Get all top-up transactions for a user
export async function getTransactionsByUserId(userId: number) {
  try {
    const results = await query(
      `SELECT id, amount, status, created_at, payment_method, notes
       FROM transactions
       WHERE user_id = $1 AND type = 'top_up'
       ORDER BY created_at DESC`,
      [userId],
    )
    return results
  } catch (error) {
    console.error("Error fetching transactions:", error)
    return []
  }
}
